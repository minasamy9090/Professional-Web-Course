# Landing Page

## Description

HTML page linked with css file to style it and javascript file to make it dynamic.

## Contents

**css.**
style.css.
**js.**
app.js.
**index.html.**
**README.md.**

## Development

Project contains **HTML,CSS ,and JS code.**

## Contributing

If you found anything that is not 100% satisfying to you, please open an issue.

## How to use

Open the **index.html** with any web browser.

## Authors and acknowledgment

Mina Samy Hannalla
